//
//  AlumnoTableViewCell.swift
//  DemoTabla
//
//  Created by Alumno-DG on 21/09/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class AlumnoTableViewCell: UITableViewCell {

    @IBOutlet weak var lblNombre: UILabel!
    
    var nombreAlumno: String!{
        
        didSet{
            self.actualizarData()
        }
    }
    
    func actualizarData(){
        self.lblNombre.text = self.nombreAlumno
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
