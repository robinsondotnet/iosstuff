//
//  AlumnoBE.swift
//  DemoTable2
//
//  Created by Alumno-DG on 28/09/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import Foundation

class AlumnoBE{
    
    var alumno_nombre           = ""
    var alumno_apellido         = ""
    var alumno_dni              = ""
    var alumno_observaciones    = ""
    var alumno_urlImagen        = ""
    var alumno_direccion        = ""
    var alumno_telefono         = ""
    var alumno_distrito         = ""
    
}
