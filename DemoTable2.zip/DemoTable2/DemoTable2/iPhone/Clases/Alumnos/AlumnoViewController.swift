//
//  AlumnoViewController.swift
//  DemoTable2
//
//  Created by Alumno-DG on 28/09/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class AlumnoViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var arrayAlumnos = [AlumnoBE]()
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayAlumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "AlumnoTableViewCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! AlumnoTableViewCell
        cell.objAlumno = self.arrayAlumnos[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let objAlumno = self.arrayAlumnos[indexPath.row]
        self.performSegue(withIdentifier: "DetalleAlumnoViewController", sender: objAlumno)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "DetalleAlumnoViewController" {
            let controller = segue.destination as! DetalleAlumnoViewController
            controller.objAlumno = sender as! AlumnoBE
        }
        
    }
    
    func agregarData(){
        
        let obj1 = AlumnoBE()
        obj1.alumno_nombre = "Guido Russell"
        obj1.alumno_apellido = "Robles Caya"
        obj1.alumno_dni = "87654321"
        obj1.alumno_direccion = "En el parque!"
        obj1.alumno_distrito = "Los olvidados de dios"
        obj1.alumno_telefono = "987654321"
        obj1.alumno_observaciones = "Se queda dormido en la clase del profe kenyi!! SO BAD!"
        self.arrayAlumnos.append(obj1)
        
        let obj2 = AlumnoBE()
        obj2.alumno_nombre = "Carolina"
        obj2.alumno_apellido = "Huamanciza"
        obj2.alumno_dni = "87654321"
        obj2.alumno_direccion = "En su casa"
        obj2.alumno_distrito = "Callao!"
        obj2.alumno_telefono = "987654321"
        obj2.alumno_observaciones = "Tambien se queda dormido en la clase del profe kenyi!! SO BAD!"
        self.arrayAlumnos.append(obj2)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.agregarData()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
