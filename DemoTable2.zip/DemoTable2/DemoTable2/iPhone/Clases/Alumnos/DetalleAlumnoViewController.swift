//
//  DetalleAlumnoViewController.swift
//  DemoTable2
//
//  Created by Alumno-DG on 28/09/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class DetalleAlumnoViewController: UIViewController {

    @IBOutlet weak var lblNombreCompleto: UILabel!
    @IBOutlet weak var lblDireccion     : UILabel!
    @IBOutlet weak var lblDNI           : UILabel!
    @IBOutlet weak var lblObservaciones : UILabel!
    
    var objAlumno : AlumnoBE!
    
    func actualizarData(){
        
        self.lblNombreCompleto.text = "\(self.objAlumno.alumno_nombre) \(self.objAlumno.alumno_apellido)"
        self.lblDNI.text = self.objAlumno.alumno_dni
        self.lblDireccion.text = self.objAlumno.alumno_direccion
        self.lblObservaciones.text = self.objAlumno.alumno_observaciones
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.actualizarData()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
