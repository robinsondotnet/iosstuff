//
//  AlumnoTableViewCell.swift
//  DemoTable2
//
//  Created by Alumno-DG on 28/09/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class AlumnoTableViewCell: UITableViewCell {

    @IBOutlet weak var lblNombreCompleto: UILabel!
    @IBOutlet weak var lblDireccion     : UILabel!
    @IBOutlet weak var lblDNI           : UILabel!
    @IBOutlet weak var lblObservaciones : UILabel!

    var objAlumno : AlumnoBE!{
        didSet{
            self.actualizarData()
        }
    }
    
    func actualizarData(){
        
        self.lblNombreCompleto.text = "\(self.objAlumno.alumno_nombre) \(self.objAlumno.alumno_apellido)"
        self.lblDNI.text = self.objAlumno.alumno_dni
        self.lblDireccion.text = self.objAlumno.alumno_direccion
        self.lblObservaciones.text = self.objAlumno.alumno_observaciones
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
