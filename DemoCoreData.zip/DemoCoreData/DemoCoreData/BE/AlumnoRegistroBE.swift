//
//  AlumnoRegistroBE.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 19/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class AlumnoRegistroBE: NSObject {

    var alumno_nombre   = ""
    var alumno_apellido = ""
    var alumno_dni      = ""
}
