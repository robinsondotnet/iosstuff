//
//  AlumnoBL.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 26/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class AlumnoBL: NSObject {

    class func listar(_ alumnos : @escaping AlumnosResultado){
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let arrayAlumnos = AlumnoDA.listarTodos(appDelegate.persistentContainer.viewContext)
        alumnos(arrayAlumnos)
    }
    
    class func agregar(_ objAlumno: AlumnoRegistroBE, conProcesoCorrecto correcto: @escaping ProcesoCorrecto, conError error: mensajeError){
        
        if objAlumno.alumno_nombre.count == 0 {
            error(Mensajes.nombreAlumnoError)
        }else if objAlumno.alumno_apellido.count == 0 {
            error(Mensajes.apellidoAlumnoError)
        }else if objAlumno.alumno_dni.count == 0{
            error(Mensajes.dniAlumnoError)
        }else{
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            _ = AlumnoDA.agregar(objAlumno, enContexto: appDelegate.persistentContainer.viewContext)
            appDelegate.saveContext()
            correcto()
        }
        
    }
    
}
