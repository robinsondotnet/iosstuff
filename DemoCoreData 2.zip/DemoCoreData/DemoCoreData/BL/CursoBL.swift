//
//  CursoBL.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 26/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class CursoBL: NSObject {

    class func listar(_ alumnos : @escaping CursoResultado){
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let arrayCursos = CursoDA.listarTodos(appDelegate.persistentContainer.viewContext)
        alumnos(arrayCursos)
    }
    
    class func agregar(_ objCurso: CursoRegistroBE, conProcesoCorrecto correcto: @escaping ProcesoCorrecto, conError error: mensajeError){
        
        if objCurso.curso_codigo.count == 0 {
            error(Mensajes.idCursoError)
        }else if objCurso.curso_nombre.count == 0 {
            error(Mensajes.nombreCursoError)
        }else if objCurso.curso_creditos == 0{
            error(Mensajes.creditosCursoError)
        }else{
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            _ = CursoDA.agregar(objCurso, enContexto: appDelegate.persistentContainer.viewContext)
            appDelegate.saveContext()
            correcto()
        }
    }
}
