//
//  MatriculaTableViewCell.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 26/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class MatriculaTableViewCell: UITableViewCell {

    @IBOutlet weak var lblHorario   : UILabel!
    @IBOutlet weak var lblSalon     : UILabel!
    @IBOutlet weak var lblCurso     : UILabel!
    @IBOutlet weak var lblAlumno    : UILabel!
    
    var objClase: Clase!{
        didSet{
            self.updateData()
        }
    }
    
    func updateData(){
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
