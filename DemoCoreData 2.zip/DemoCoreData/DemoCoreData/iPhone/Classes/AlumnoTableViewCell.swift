//
//  AlumnoTableViewCell.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 26/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class AlumnoTableViewCell: UITableViewCell {

    @IBOutlet weak var lblNombre: UILabel!
    
    var objAlumno: Alumno!{
        didSet{
            self.updateData()
        }
    }
    
    func updateData(){
        
        self.lblNombre.text = "\(self.objAlumno.apellido ?? "") \(self.objAlumno.nombre ?? "")"
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
