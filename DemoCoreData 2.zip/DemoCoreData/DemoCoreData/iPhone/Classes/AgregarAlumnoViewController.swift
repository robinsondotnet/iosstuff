//
//  AgregarAlumnoViewController.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 26/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class AgregarAlumnoViewController: UIViewController {

    @IBOutlet weak var txtNombre    : UITextField!
    @IBOutlet weak var txtApellido  : UITextField!
    @IBOutlet weak var txtDni       : UITextField!
    
    @IBAction func clickBtnAgregar(_ sender: Any){
        
        let objAlumnoRegistro = AlumnoRegistroBE()
        objAlumnoRegistro.alumno_nombre     = self.txtNombre.text ?? ""
        objAlumnoRegistro.alumno_apellido   = self.txtApellido.text ?? ""
        objAlumnoRegistro.alumno_dni        = self.txtDni.text ?? ""
        
        AlumnoBL.agregar(objAlumnoRegistro, conProcesoCorrecto: {
            
            self.navigationController?.popViewController(animated: true)
            
        }) { (mensajeError) in
            
            self.showAltert(withTitle: Mensajes.errorTitle, withMessage: mensajeError, withAcceptButton: Mensajes.alertAceptar, withCompletion: nil)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
