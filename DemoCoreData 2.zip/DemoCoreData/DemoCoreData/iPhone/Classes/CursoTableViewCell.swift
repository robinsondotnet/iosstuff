//
//  CursoTableViewCell.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 26/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class CursoTableViewCell: UITableViewCell {

    @IBOutlet weak var lblDetalle: UILabel!
    
    var objCurso: Curso!{
        didSet{
            self.updateData()
        }
    }
    
    func updateData(){
        self.lblDetalle.text = "\(self.objCurso.nombre ?? "") - \(self.objCurso.codigo ?? "")"
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
