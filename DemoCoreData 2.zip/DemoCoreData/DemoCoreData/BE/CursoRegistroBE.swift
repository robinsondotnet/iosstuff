//
//  CursoRegistroBE.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 19/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class CursoRegistroBE: NSObject {
    
    var curso_codigo    = ""
    var curso_creditos  = 0
    var curso_nombre    = ""
}
