//
//  AlumnoCursoBE.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 19/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit

class ClaseRegistroBE: NSObject {

    var clase_horaInicio  = Date()
    var clase_horaFin     = Date()
    var clase_nombreSalon = ""
    
    var clase_alumno: Alumno!
    var clase_curso: Curso!
}
