//
//  AlumnoCursoDA.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 19/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit
import CoreData

class ClaseDA: NSObject {

    class func agregar(_ clase: ClaseRegistroBE, enContexto contexto: NSManagedObjectContext) -> Clase{
        
        let objDM = NSEntityDescription.insertNewObject(forEntityName: "Clase", into: contexto) as! Clase
        
        objDM.horaFin       = clase.clase_horaFin
        objDM.horaInicio    = clase.clase_horaInicio
        objDM.nombreSalon   = clase.clase_nombreSalon
        
        clase.clase_alumno.addToClases(objDM)
        clase.clase_curso.addToClases(objDM)
        
        return objDM
    }
}
