//
//  AlumnoDA.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 19/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit
import CoreData

class AlumnoDA: NSObject {

    @discardableResult class func agregar(_ alumno: AlumnoRegistroBE, enContexto contexto: NSManagedObjectContext) -> Alumno{
        
        let objDM = NSEntityDescription.insertNewObject(forEntityName: "Alumno", into: contexto) as! Alumno
        
        objDM.apellido  = alumno.alumno_apellido
        objDM.nombre    = alumno.alumno_nombre
        objDM.dni       = alumno.alumno_dni
        
        return objDM
    }
    
    class func listarTodos(_ contexto: NSManagedObjectContext) -> [Alumno]{
        
        let fetchRequest : NSFetchRequest<Alumno> = Alumno.fetchRequest()
        
        let sortApellido = NSSortDescriptor(key: "apellido", ascending: true)
        let sortNombre = NSSortDescriptor(key: "nombre", ascending: true)
        
        fetchRequest.sortDescriptors = [sortApellido, sortNombre]
        
        do{
            let array = try contexto.fetch(fetchRequest)
            return array
        }catch{
            return []
        }
    } 
}
