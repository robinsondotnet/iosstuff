//
//  CursoDA.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 19/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import UIKit
import CoreData

class CursoDA: NSObject {

    class func agregar(_ curso: CursoRegistroBE, enContexto contexto: NSManagedObjectContext) -> Curso{
        
        let objDM = NSEntityDescription.insertNewObject(forEntityName: "Curso", into: contexto) as! Curso
        
        objDM.nombre = curso.curso_nombre
        objDM.creditos = Int32(curso.curso_creditos)
        objDM.codigo = curso.curso_codigo
        
        return objDM
    }
    
    class func listarTodos(_ contexto: NSManagedObjectContext) -> [Curso]{
        
        let fetchRequest : NSFetchRequest<Curso> = Curso.fetchRequest()
        let sortNombre = NSSortDescriptor(key: "nombre", ascending: true)
        
        fetchRequest.sortDescriptors = [sortNombre]
        
        do{
            let array = try contexto.fetch(fetchRequest)
            return array
        }catch{
            return []
        }
    }
}
