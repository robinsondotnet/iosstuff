//
//  Constantes.swift
//  DemoCoreData
//
//  Created by Alumno-DG on 26/10/18.
//  Copyright © 2018 Alumno-DG. All rights reserved.
//

import Foundation

typealias mensajeError      = (_ mensaje: String) -> Void
typealias AlumnosResultado  = (_ arrayAlumnos: [Alumno]) -> Void
typealias CursoResultado    = (_ arrayCursos: [Curso]) -> Void
typealias ProcesoCorrecto   = () -> Void


struct Mensajes {
    
    static let errorTitle           = "Ups. ocurrio un error."
    static let alertAceptar         = "Aceptar"
    static let alertCancelar        = "Cancelar"
    static let nombreAlumnoError    = "Ingresa un nombre válido para el alumno."
    static let apellidoAlumnoError  = "Ingresa un apellido válido para el alumno."
    static let dniAlumnoError       = "Ingresa un dni válido para el alumno."
    static let idCursoError         = "Ingresa un código válido para el curso."
    static let nombreCursoError     = "Ingresa un nombre válido para el curso."
    static let creditosCursoError   = "Ingresa una cantidad de créditos válidos para el curso."
}
